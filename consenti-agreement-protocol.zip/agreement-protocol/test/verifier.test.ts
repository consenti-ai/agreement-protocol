/**
 * Basic test suite for the Consenti reference verifier.
 * Run with: npx tsx --test test/verifier.test.ts
 */

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  canonicalize,
  sha256,
  computeAgreementHash,
  computeAcceptorHash,
  verify,
  VerificationLevel,
} from '../src/verifier';
import type { AcceptanceRecord, AnchorProvider, AnchorRecord } from '../src/verifier';

// ─── Canonicalization Tests ──────────────────────────────────────────────────

describe('canonicalize (RFC 8785)', () => {
  it('sorts object keys alphabetically', () => {
    assert.equal(canonicalize({ b: 2, a: 1 }), '{"a":1,"b":2}');
  });

  it('handles nested objects', () => {
    assert.equal(
      canonicalize({ z: { b: 2, a: 1 }, a: 0 }),
      '{"a":0,"z":{"a":1,"b":2}}'
    );
  });

  it('handles arrays (preserves order)', () => {
    assert.equal(canonicalize([3, 1, 2]), '[3,1,2]');
  });

  it('handles null', () => {
    assert.equal(canonicalize(null), 'null');
  });

  it('handles strings with escaping', () => {
    assert.equal(canonicalize('hello "world"'), '"hello \\"world\\""');
  });

  it('handles booleans', () => {
    assert.equal(canonicalize(true), 'true');
    assert.equal(canonicalize(false), 'false');
  });

  it('handles empty objects and arrays', () => {
    assert.equal(canonicalize({}), '{}');
    assert.equal(canonicalize([]), '[]');
  });

  it('omits undefined values', () => {
    assert.equal(canonicalize({ a: 1, b: undefined }), '{"a":1}');
  });

  it('is deterministic across identical inputs', () => {
    const obj = { publisher: { display_name: 'Test', identifier: { type: 'domain', value: 'test.com' } } };
    assert.equal(canonicalize(obj), canonicalize(obj));
  });
});

// ─── Hashing Tests ───────────────────────────────────────────────────────────

describe('sha256', () => {
  it('produces consistent hashes', () => {
    const hash = sha256('hello');
    assert.equal(hash, '2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824');
  });

  it('produces different hashes for different inputs', () => {
    assert.notEqual(sha256('hello'), sha256('world'));
  });
});

// ─── Agreement Hash Tests ────────────────────────────────────────────────────

describe('computeAgreementHash', () => {
  const baseRecord: AcceptanceRecord = {
    protocol_version: 'consenti/v0.1',
    agreement_id: 'test_agreement_001',
    created_at: '2026-04-16T09:00:00Z',
    publisher: {
      identifier: { type: 'domain', value: 'example.com' },
      display_name: 'Example Corp',
    },
    acceptor: {
      acceptor_type: 'human' as const,
      identifier: { type: 'email', value: 'user@test.com' },
      accepted_at: '2026-04-16T09:00:00Z',
    },
    terms_ref: {
      terms_hash: 'sha256:abc123',
      terms_url: 'https://example.com/terms',
    },
    canonicalization: {
      method: 'RFC8785' as const,
      hash_algorithm: 'SHA-256' as const,
      excluded_fields: ['anchoring', 'signatures', 'privacy.anchor_commitment', 'privacy.merkle_tree.root'],
    },
  };

  it('produces a hash', () => {
    const hash = computeAgreementHash(baseRecord);
    assert.ok(hash.length === 64, 'SHA-256 should produce 64 hex characters');
  });

  it('is deterministic', () => {
    const hash1 = computeAgreementHash(baseRecord);
    const hash2 = computeAgreementHash(baseRecord);
    assert.equal(hash1, hash2);
  });

  it('excludes anchoring from hash', () => {
    const withAnchoring: AcceptanceRecord = {
      ...baseRecord,
      anchoring: {
        method: 'pangea',
        transaction_ref: 'tx_123',
        anchored_at: '2026-04-16T09:00:05Z',
        agreement_hash: 'sha256:will_be_ignored',
      },
    };
    assert.equal(
      computeAgreementHash(baseRecord),
      computeAgreementHash(withAnchoring),
      'Anchoring field should not affect hash'
    );
  });

  it('excludes signatures from hash', () => {
    const withSigs: AcceptanceRecord = {
      ...baseRecord,
      signatures: [{
        signer: 'acceptor' as const,
        algorithm: 'ES256',
        public_key_ref: 'did:web:test#key-1',
        signature: 'placeholder',
        signed_at: '2026-04-16T09:00:00Z',
      }],
    };
    assert.equal(
      computeAgreementHash(baseRecord),
      computeAgreementHash(withSigs),
      'Signatures should not affect hash'
    );
  });

  it('changes when terms_ref changes', () => {
    const modified: AcceptanceRecord = {
      ...baseRecord,
      terms_ref: {
        terms_hash: 'sha256:different',
        terms_url: 'https://example.com/terms-v2',
      },
    };
    assert.notEqual(
      computeAgreementHash(baseRecord),
      computeAgreementHash(modified),
      'Different terms should produce different hash'
    );
  });

  it('changes when acceptor changes', () => {
    const modified: AcceptanceRecord = {
      ...baseRecord,
      acceptor: {
        ...baseRecord.acceptor,
        identifier: { type: 'email', value: 'other@test.com' },
      },
    };
    assert.notEqual(
      computeAgreementHash(baseRecord),
      computeAgreementHash(modified),
      'Different acceptor should produce different hash'
    );
  });
});

// ─── Acceptor Hash Tests ─────────────────────────────────────────────────────

describe('computeAcceptorHash', () => {
  it('produces consistent pseudonymous hashes', () => {
    const hash = computeAcceptorHash({ type: 'email', value: 'john@example.com' });
    assert.ok(hash.length === 64);
    assert.equal(hash, computeAcceptorHash({ type: 'email', value: 'john@example.com' }));
  });

  it('produces different hashes for different identifiers', () => {
    assert.notEqual(
      computeAcceptorHash({ type: 'email', value: 'john@example.com' }),
      computeAcceptorHash({ type: 'email', value: 'jane@example.com' })
    );
  });
});

// ─── Verification Tests ──────────────────────────────────────────────────────

describe('verify', () => {
  const record: AcceptanceRecord = {
    protocol_version: 'consenti/v0.1',
    agreement_id: 'test_verify_001',
    created_at: '2026-04-16T09:00:00Z',
    publisher: {
      identifier: { type: 'domain', value: 'example.com' },
    },
    acceptor: {
      acceptor_type: 'human' as const,
      identifier: { type: 'email', value: 'user@test.com' },
      accepted_at: '2026-04-16T09:00:00Z',
    },
    terms_ref: {
      terms_hash: 'sha256:abc123',
      terms_url: 'https://example.com/terms',
      terms_title: 'Test Terms',
    },
    canonicalization: {
      method: 'RFC8785' as const,
      hash_algorithm: 'SHA-256' as const,
      excluded_fields: ['anchoring', 'signatures', 'privacy.anchor_commitment', 'privacy.merkle_tree.root'],
    },
  };

  const agreementHash = computeAgreementHash(record);

  const mockProvider: AnchorProvider = {
    name: 'mock',
    async resolve(hash: string): Promise<AnchorRecord | null> {
      if (hash === agreementHash) {
        return {
          agreement_hash: hash,
          anchored_at: '2026-04-16T09:00:05Z',
          transaction_ref: 'mock_tx_001',
        };
      }
      return null;
    },
  };

  it('Level 0: confirms existence on anchor', async () => {
    const result = await verify(record, {
      level: VerificationLevel.EXISTENCE,
      anchorProvider: mockProvider,
    });
    assert.ok(result.valid);
    assert.equal(result.level, VerificationLevel.EXISTENCE);
    assert.ok(result.anchorFound);
    assert.equal(result.anchoredAt, '2026-04-16T09:00:05Z');
  });

  it('Level 0: fails when anchor not found', async () => {
    const noAnchor: AnchorProvider = {
      name: 'empty',
      async resolve(): Promise<AnchorRecord | null> { return null; },
    };
    const result = await verify(record, {
      level: VerificationLevel.EXISTENCE,
      anchorProvider: noAnchor,
    });
    assert.ok(!result.valid);
    assert.ok(!result.anchorFound);
    assert.ok(result.errors.length > 0);
  });

  it('Level 1: confirms acceptor and terms', async () => {
    const result = await verify(record, {
      level: VerificationLevel.ACCEPTANCE_PROOF,
      anchorProvider: mockProvider,
    });
    assert.ok(result.valid);
    assert.equal(result.acceptor, 'user@test.com');
    assert.equal(result.termsHash, 'sha256:abc123');
    assert.equal(result.termsTitle, 'Test Terms');
  });

  it('Level 2: reports missing signatures for agents', async () => {
    const agentRecord: AcceptanceRecord = {
      ...record,
      acceptor: {
        ...record.acceptor,
        acceptor_type: 'agent' as const,
        identifier: { type: 'agent_id', value: 'agent://test/v1' },
      },
    };
    const agentHash = computeAgreementHash(agentRecord);
    const agentProvider: AnchorProvider = {
      name: 'mock-agent',
      async resolve(hash: string): Promise<AnchorRecord | null> {
        if (hash === agentHash) {
          return { agreement_hash: hash, anchored_at: '2026-04-16T09:00:05Z', transaction_ref: 'tx' };
        }
        return null;
      },
    };

    const result = await verify(agentRecord, {
      level: VerificationLevel.FULL,
      anchorProvider: agentProvider,
    });
    assert.ok(result.valid); // valid but with warnings
    assert.ok(result.warnings.some(w => w.includes('Agent acceptor has no signatures')));
  });

  it('detects hash tampering', async () => {
    const tampered: AcceptanceRecord = {
      ...record,
      anchoring: {
        method: 'pangea',
        agreement_hash: 'sha256:00000000000000000000000000000000',
        anchored_at: '2026-04-16T09:00:05Z',
        transaction_ref: 'tx_bad',
      },
    };
    const result = await verify(tampered, {
      level: VerificationLevel.EXISTENCE,
      anchorProvider: mockProvider,
    });
    assert.ok(!result.valid);
    assert.ok(result.errors.some(e => e.includes('Hash mismatch')));
  });
});
